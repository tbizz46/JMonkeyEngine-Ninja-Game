#import "Common/ShaderLib/GLSLCompat.glsllib"
 //Credits 
 //https://github.com/manuelbua/libgdx-contribs
 // http://blenderartists.org/forum/showthread.php?209574-Full-Screen-Anti-Aliasing-(NFAA-DLAA-SSAA)
 // http://www.gamedev.net/topic/580517-nfaa---a-post-process-anti-aliasing-filter-results-implementation-details/
 
uniform sampler2D m_Texture;
varying vec2 texCoord;
uniform vec2 g_ResolutionInverse;
uniform vec2 g_Resolution;
vec3 oneThird = vec3(0.33, 0.33, 0.33) ;


float lumRGB(vec3 v)
    {
    return dot(v, vec3(0.212, 0.716, 0.072));
    }

 const float fScale = 1.0;
float GetColorLuminance(vec3 i_vColor){
    return dot(i_vColor, vec3(0.2126, 0.7152, 0.0722));
}

vec4 nfaa(sampler2D texture, vec2 texCoords, vec2 viewportInverse){
    // Offset coordinates
    vec2 upOffset = vec2(0.0, viewportInverse.y) * fScale;
    vec2 rightOffset = vec2(viewportInverse.x, 0.0) * fScale;
    
    float topHeight = lumRGB(texture2D(texture, texCoords.xy + upOffset).rgb);
    float bottomHeight = lumRGB(texture2D(texture, texCoords.xy - upOffset).rgb);
    float rightHeight = lumRGB(texture2D(texture, texCoords.xy + rightOffset).rgb);
    float leftHeight = lumRGB(texture2D(texture, texCoords.xy - rightOffset).rgb);
    float leftTopHeight = lumRGB(texture2D(texture, texCoords.xy - rightOffset + upOffset).rgb);
    float leftBottomHeight = lumRGB(texture2D(texture, texCoords.xy - rightOffset - upOffset).rgb);
    float rightBottomHeight = lumRGB(texture2D(texture, texCoords.xy + rightOffset + upOffset).rgb);
    float rightTopHeight = lumRGB(texture2D(texture, texCoords.xy + rightOffset - upOffset).rgb);
    
    // Normal map creation
    float sum0 = rightTopHeight + topHeight + rightBottomHeight;
    float sum1 = leftTopHeight + bottomHeight + leftBottomHeight;
    float sum2 = leftTopHeight + leftHeight + rightTopHeight;
    float sum3 = leftBottomHeight + rightHeight + rightBottomHeight;
    float vect1 = (sum1 - sum0);
    float vect2 = (sum2 - sum3);
    
    // Put them together and scale.
    vec2 Normal = vec2(vect1, vect2) * viewportInverse * fScale;
    
    // Color
    vec4 Scene0 = texture2D(texture, texCoords.xy);
    vec4 Scene1 = texture2D(texture, texCoords.xy + Normal.xy);
    vec4 Scene2 = texture2D(texture, texCoords.xy - Normal.xy);
    vec4 Scene3 = texture2D(texture, texCoords.xy + vec2(Normal.x, -Normal.y) * 0.5);
    vec4 Scene4 = texture2D(texture, texCoords.xy - vec2(Normal.x, -Normal.y) * 0.5);
    
    // Final color
    return vec4((Scene0.rgb + Scene1.rgb + Scene2.rgb + Scene3.rgb + Scene4.rgb) * 0.2, 1.0);
    
    // Debug
    //return vec4(normalize(vec3(vect1, vect2 , 1.0) * 0.5 + 0.5), 1.0);
	    
}


 
void main() {
 
     gl_FragColor = nfaa(m_Texture, texCoord, g_ResolutionInverse);
       
    }
 